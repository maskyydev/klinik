<?php

return [
    'dibuka' => true, // Ubah ke false jika ingin menutup default-nya
];
