<?php if($konfirmasi->count() > 0): ?>
    <?php $__currentLoopData = $konfirmasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="p-4 border-b text-center">
            <h1 class="font-bold text-green-600 text-lg">
                PASIEN DENGAN NAMA <?php echo e($data->nama ?? '-'); ?> SEDANG DALAM PROSES 
                <span class="font-bold text-yellow-600 text-lg"><?php echo e($data->pilihan ?? '-'); ?></span>
            </h1>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="p-4 border-b text-center">
        <h1 class="font-bold text-red-600 text-lg">Tidak ada pasien yang sedang konsultasi !!!</h1>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\tugasakhir\resources\views/daftar/_partial_antrian.blade.php ENDPATH**/ ?>