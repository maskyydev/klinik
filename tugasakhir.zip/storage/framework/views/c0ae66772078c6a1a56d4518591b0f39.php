

<?php $__env->startSection('title', 'Riwayat Didaftarkan'); ?>

<?php $__env->startSection('content'); ?>
<!-- Konten Pendaftaran Pasien -->
<div class="mx-auto my-8 p-8 bg-white shadow-md rounded-md w-full max-w-4xl animate__animated animate__zoomIn">
    <h1 class="text-2xl font-semibold mb-4"><?php echo e($title); ?></h1>

    <!-- Tabel Riwayat -->
    <div class="overflow-x-auto">
        <table class="min-w-full bg-white border border-gray-300 text-sm sm:text-base">
            <thead class="bg-gray-200 text-left">
    <tr class="text-center">
        <th class="p-3">No Antrian</th>
        <th class="p-3">Nama Pasien</th>
        <th class="p-3 hidden md:table-cell">Nomor Telepon</th>
        <th class="p-3 hidden md:table-cell">Tanggal</th>
        <th class="p-3">Pilihan</th> <!-- Tambah kolom pilihan -->
    </tr>
</thead>
<tbody>
    <?php if($pasienData->count() > 0): ?>
        <?php $__currentLoopData = $pasienData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pasien): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center border-b">
                <td class="p-3">A00<?php echo e($pasien->id); ?></td>
                <td class="p-3"><?php echo e($pasien->nama); ?></td>
                <td class="p-3 hidden md:table-cell"><?php echo e($pasien->nomor_telepon); ?></td>
                <td class="p-3 hidden md:table-cell">
                    <?php echo e(\Carbon\Carbon::parse($pasien->tanggal_daftar)->translatedFormat('d F Y')); ?>

                </td>
                <td class="p-3 text-center">
                    <?php if(empty($pasien->pilihan)): ?>
                        <span class="font-bold text-black">WAITING ...</span>
                    <?php elseif($pasien->pilihan === 'SELESAI'): ?>
                        <span class="font-bold text-green-600">SUCCES !!!</span>
                    <?php elseif($pasien->pilihan === 'KONSULTASI'): ?>
                        <span class="font-bold text-yellow-500">PROCCES ...</span>
                    <?php elseif($pasien->pilihan === 'DIBATALKAN'): ?>
                        <span class="font-bold text-red-600">CANCEL !!!</span>
                    <?php else: ?>
                        <?php echo e($pasien->pilihan ?? '-'); ?>

                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
            <td colspan="5" class="py-2 px-4 text-center">Tidak ada data</td>
        </tr>
    <?php endif; ?>
</tbody>
        </table>
    </div>

    <!-- Pagination Controls -->
    <div class="flex justify-center mt-4">
        <?php echo e($pasienData->links('pagination::tailwind')); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugasakhir\resources\views/daftar/riwayat.blade.php ENDPATH**/ ?>