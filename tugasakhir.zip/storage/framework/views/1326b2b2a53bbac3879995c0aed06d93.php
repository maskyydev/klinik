

<?php $__env->startSection('title', 'Riwayat Data Pasien'); ?>

<?php $__env->startSection('content'); ?>

<main class="p-4 md:p-8 max-w-7xl mx-auto">

  <div class="bg-white p-6 rounded shadow animate__animated animate__fadeInUp">
    <h2 class="text-xl font-semibold mb-4"><?php echo e($title); ?></h2>

    <?php if(session('success')): ?>
      <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    <!-- Container fleksibel untuk form dan tombol refresh -->
    <div class="flex justify-between items-center mb-4 gap-2 w-full">
        <!-- Form Pencarian -->
        <form action="<?php echo e(route('riwayat.pasien')); ?>" method="GET" class="flex flex-grow max-w-md">
            <?php echo csrf_field(); ?>
            <input
                type="text"
                name="search"
                placeholder="Cari nama pasien"
                value="<?php echo e(request('search')); ?>"
                class="flex-grow px-3 py-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-blue-500"/>
            <button
                type="submit"
                class="px-4 py-2 bg-blue-500 text-white rounded-r-md hover:bg-blue-600 transition">
                Cari
            </button>
        </form>

        <!-- Tombol Refresh di kanan -->
        <div>
            <a href="<?php echo e(url('/riwayatpasien')); ?>" title="Refresh">
                <img src="<?php echo e(asset('img/refresh.png')); ?>" alt="refresh" class="w-8 h-8 hover:opacity-75 transition" />
            </a>
        </div>
    </div>

    <!-- Tabel Riwayat -->
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm border border-gray-300">
        <thead class="bg-gray-100 text-gray-700">
          <tr>
            <th class="px-4 py-2 border">No</th>
            <th class="px-4 py-2 border">Nama Pasien</th>
            <th class="px-4 py-2 border hidden md:table-cell">Alamat</th>
            <th class="px-4 py-2 border hidden md:table-cell">Tanggal Daftar</th>
            <th class="px-4 py-2 border hidden md:table-cell">Jenis Kelamin</th>
            <th class="px-4 py-2 border hidden md:table-cell">Nomor Telepon</th>
            <th class="px-4 py-2 border">Kondisi</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $konfirmasiData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="text-gray-800 text-sm">
                <td class="border px-4 py-2"><?php echo e($konfirmasiData->firstItem() + $index); ?></td>
                <td class="border px-4 py-2"><?php echo e($item->nama); ?></td>
                <td class="border px-4 py-2 hidden md:table-cell"><?php echo e($item->alamat); ?></td>
                <td class="border px-4 py-2 hidden md:table-cell">
                    <?php echo e(\Carbon\Carbon::parse($item->tanggal_daftar)->translatedFormat('d F Y')); ?>

                </td>
                <td class="border px-4 py-2 hidden md:table-cell"><?php echo e($item->jenkel); ?></td>
                <td class="border px-4 py-2 hidden md:table-cell"><?php echo e($item->nomor_telepon); ?></td>
                <td class="border px-4 py-2 capitalize">
                    <?php if(strtolower($item->pilihan) == 'konsultasi'): ?>
                        <span class="text-yellow-600 font-bold"><?php echo e($item->pilihan); ?></span>
                    <?php elseif(strtolower($item->pilihan) == 'dibatalkan'): ?>
                        <span class="text-red-600 font-bold"><?php echo e($item->pilihan); ?></span>
                    <?php elseif(strtolower($item->pilihan) == 'selesai'): ?>
                        <span class="text-green-600 font-bold"><?php echo e($item->pilihan); ?></span>
                    <?php else: ?>
                        <?php echo e($item->pilihan); ?>

                    <?php endif; ?>
                </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="7" class="text-center py-4 text-gray-500">Data riwayat tidak ditemukan.</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- Pagination -->
    <div class="mt-4">
      <?php echo e($konfirmasiData->withQueryString()->links('pagination::tailwind')); ?>

    </div>

  </div>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tugasakhir\resources\views/sidebar/riwayat.blade.php ENDPATH**/ ?>