<?php if($paginator->hasPages()): ?>
    <div class="flex justify-between items-center mt-4 mx-4">
        
        <div>
            <?php if($paginator->onFirstPage()): ?>
                <span class="px-4 py-2 bg-gray-300 text-gray-500 rounded opacity-50 cursor-not-allowed">Previous</span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="px-4 py-2 bg-gray-300 hover:bg-gray-400 focus:bg-blue-500 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">Previous</a>
            <?php endif; ?>
        </div>

        
        <div class="ml-auto">
            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="px-4 py-2 bg-gray-300 hover:bg-gray-400 focus:bg-blue-500 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50">Next</a>
            <?php else: ?>
                <span class="px-4 py-2 bg-gray-300 text-gray-500 rounded opacity-50 cursor-not-allowed">Next</span>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\tugasakhir\resources\views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>